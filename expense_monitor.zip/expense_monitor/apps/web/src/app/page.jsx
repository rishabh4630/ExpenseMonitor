"use client";
import { useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  Building2,
  Receipt,
  Users,
  BarChart3,
  CheckCircle,
  Clock,
  Shield,
} from "lucide-react";

export default function HomePage() {
  const { data: user, loading } = useUser();

  useEffect(() => {
    if (!loading && user) {
      // Redirect authenticated users to dashboard
      window.location.href = "/dashboard";
    }
  }, [user, loading]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#18B84E] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  // Show landing page for unauthenticated users
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#121212]">
      {/* Header */}
      <header className="bg-white dark:bg-[#1E1E1E] border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-[#18B84E] dark:bg-[#16A249] rounded flex items-center justify-center">
                <span className="text-white font-bold text-sm">EX</span>
              </div>
              <span className="ml-2 text-xl font-bold text-gray-900 dark:text-white">
                ExpenseFlow
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="/account/signin"
                className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 px-3 py-2 rounded-md text-sm font-medium"
              >
                Sign In
              </a>
              <a
                href="/account/signup"
                className="bg-[#18B84E] dark:bg-[#16A249] hover:bg-[#16A249] dark:hover:bg-[#14D45D] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-150"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Expense Management
            <span className="block text-[#18B84E] dark:text-[#16A249]">
              Made Simple
            </span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8 max-w-3xl mx-auto">
            Streamline your company's expense reporting with automated receipt
            processing, multi-level approvals, and real-time insights.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/account/signup"
              className="bg-[#18B84E] dark:bg-[#16A249] hover:bg-[#16A249] dark:hover:bg-[#14D45D] text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-150"
            >
              Start Free Trial
            </a>
            <a
              href="#features"
              className="border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-150"
            >
              Learn More
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white dark:bg-[#1E1E1E]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Everything you need to manage expenses
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              From receipt capture to approval workflows, we've got you covered.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-[#18B84E]/10 dark:bg-[#16A249]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Receipt className="w-8 h-8 text-[#18B84E] dark:text-[#16A249]" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Smart Receipt Processing
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Upload receipts and let our AI extract all the details
                automatically. No more manual data entry.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-[#18B84E]/10 dark:bg-[#16A249]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-[#18B84E] dark:text-[#16A249]" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Multi-Level Approvals
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Configure approval workflows that match your company hierarchy
                and spending policies.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-[#18B84E]/10 dark:bg-[#16A249]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-8 h-8 text-[#18B84E] dark:text-[#16A249]" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Real-time Analytics
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Get insights into spending patterns, budget utilization, and
                expense trends across your organization.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-[#18B84E]/10 dark:bg-[#16A249]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-[#18B84E] dark:text-[#16A249]" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Team Management
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Easily manage employees, assign roles, and define reporting
                hierarchies within your organization.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-[#18B84E]/10 dark:bg-[#16A249]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-[#18B84E] dark:text-[#16A249]" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Fast Processing
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Speed up expense approvals with automated rules and
                notifications to keep your team moving.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-[#18B84E]/10 dark:bg-[#16A249]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-[#18B84E] dark:text-[#16A249]" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Secure & Compliant
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Enterprise-grade security with audit trails and compliance
                features to meet regulatory requirements.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Ready to streamline your expenses?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
            Join thousands of companies that trust ExpenseFlow for their expense
            management.
          </p>
          <a
            href="/account/signup"
            className="bg-[#18B84E] dark:bg-[#16A249] hover:bg-[#16A249] dark:hover:bg-[#14D45D] text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-150"
          >
            Get Started Today
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white dark:bg-[#1E1E1E] border-t border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-[#18B84E] dark:bg-[#16A249] rounded flex items-center justify-center">
                <span className="text-white font-bold text-sm">EX</span>
              </div>
              <span className="ml-2 text-lg font-semibold text-gray-900 dark:text-white">
                ExpenseFlow
              </span>
            </div>
          </div>
          <div className="mt-4 text-center">
            <p className="text-gray-500 dark:text-gray-400 text-sm">
              © 2025 ExpenseFlow. Built for modern businesses.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
