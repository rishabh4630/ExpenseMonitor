"use client";
import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import useUser from "@/utils/useUser";
import useUpload from "@/utils/useUpload";
import {
  ArrowLeft,
  Upload,
  X,
  Calendar,
  DollarSign,
  Receipt,
  FileText,
  Camera,
  Loader2,
  CheckCircle,
  AlertCircle,
  Globe,
} from "lucide-react";

export default function NewExpensePage() {
  const { data: user, loading } = useUser();
  const [upload, { loading: uploading }] = useUpload();
  const [categories, setCategories] = useState([]);
  const [receiptFile, setReceiptFile] = useState(null);
  const [receiptPreview, setReceiptPreview] = useState(null);
  const [ocrProcessing, setOcrProcessing] = useState(false);
  const [ocrData, setOcrData] = useState(null);
  const [companyData, setCompanyData] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef(null);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm({
    defaultValues: {
      title: "",
      amount: "",
      currency: "USD",
      description: "",
      categoryId: "",
      expenseDate: new Date().toISOString().split("T")[0],
    },
  });

  useEffect(() => {
    if (!loading && !user) {
      window.location.href = "/account/signin?callbackUrl=/expenses/new";
    } else if (user) {
      fetchInitialData();
    }
  }, [user, loading]);

  const fetchInitialData = async () => {
    try {
      // Fetch categories and company data
      const [categoriesResponse, companyResponse] = await Promise.all([
        fetch("/api/expenses/categories"),
        fetch("/api/companies"),
      ]);

      if (categoriesResponse.ok) {
        const categoriesData = await categoriesResponse.json();
        setCategories(categoriesData);
      }

      if (companyResponse.ok) {
        const company = await companyResponse.json();
        setCompanyData(company);
        setValue("currency", company.base_currency);
      } else if (companyResponse.status === 404) {
        window.location.href = "/setup";
      }
    } catch (error) {
      console.error("Error fetching initial data:", error);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      setReceiptFile(file);

      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setReceiptPreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const processOCR = async () => {
    if (!receiptFile) return;

    setOcrProcessing(true);
    setError(null);

    try {
      // Convert file to base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target.result;

        try {
          const response = await fetch("/api/ocr/receipt", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ imageBase64: base64 }),
          });

          if (!response.ok) {
            throw new Error("OCR processing failed");
          }

          const result = await response.json();

          if (result.success && result.extractedData) {
            setOcrData(result.extractedData);

            // Auto-fill form fields
            if (result.extractedData.amount) {
              setValue("amount", result.extractedData.amount);
            }
            if (result.extractedData.currency) {
              setValue("currency", result.extractedData.currency);
            }
            if (
              result.extractedData.merchant &&
              result.extractedData.description
            ) {
              setValue(
                "title",
                `${result.extractedData.merchant} - ${result.extractedData.description}`
              );
            } else if (result.extractedData.merchant) {
              setValue("title", result.extractedData.merchant);
            } else if (result.extractedData.description) {
              setValue("title", result.extractedData.description);
            }
            if (result.extractedData.description) {
              setValue("description", result.extractedData.description);
            }
            if (result.extractedData.date) {
              setValue("expenseDate", result.extractedData.date);
            }

            // Try to match category
            if (result.extractedData.category) {
              const matchingCategory = categories.find(
                (cat) =>
                  cat.name
                    .toLowerCase()
                    .includes(result.extractedData.category.toLowerCase()) ||
                  result.extractedData.category
                    .toLowerCase()
                    .includes(cat.name.toLowerCase())
              );
              if (matchingCategory) {
                setValue("categoryId", matchingCategory.id.toString());
              }
            }
          }
        } catch (ocrError) {
          setError(
            "Failed to process receipt. Please fill in the details manually."
          );
          console.error("OCR error:", ocrError);
        } finally {
          setOcrProcessing(false);
        }
      };
      reader.readAsDataURL(receiptFile);
    } catch (error) {
      setOcrProcessing(false);
      setError("Failed to process receipt. Please try again.");
      console.error("File reading error:", error);
    }
  };

  const onSubmit = async (data) => {
    setSubmitting(true);
    setError(null);

    try {
      let receiptUrl = null;
      let receiptFilename = null;

      // Upload receipt if present
      if (receiptFile) {
        const uploadResult = await upload({ file: receiptFile });
        if (uploadResult.error) {
          throw new Error(uploadResult.error);
        }
        receiptUrl = uploadResult.url;
        receiptFilename = receiptFile.name;
      }

      // Submit expense
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...data,
          receiptUrl,
          receiptFilename,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to submit expense");
      }

      setSuccess(true);
      setTimeout(() => {
        window.location.href = "/expenses";
      }, 2000);
    } catch (error) {
      setError(error.message);
      console.error("Error submitting expense:", error);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#18B84E] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            Expense Submitted!
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Your expense has been submitted for approval.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#121212]">
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center mb-6">
          <a
            href="/dashboard"
            className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-150"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Dashboard</span>
          </a>
        </div>

        <div className="mb-8">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white">
            Submit New Expense
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Upload a receipt and fill in the details below
          </p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Receipt Upload Section */}
            <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Receipt Upload
              </h2>

              {!receiptPreview ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-12 text-center cursor-pointer hover:border-[#18B84E] dark:hover:border-[#16A249] transition-colors duration-150"
                >
                  <Camera className="w-12 h-12 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    Upload Receipt
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    Click to upload or drag and drop your receipt
                  </p>
                  <p className="text-sm text-gray-400 dark:text-gray-500">
                    PNG, JPEG, or PDF up to 10MB
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative">
                    <img
                      src={receiptPreview}
                      alt="Receipt preview"
                      className="w-full h-64 object-contain bg-gray-50 dark:bg-gray-800 rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setReceiptFile(null);
                        setReceiptPreview(null);
                        setOcrData(null);
                      }}
                      className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors duration-150"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {!ocrData && (
                    <button
                      type="button"
                      onClick={processOCR}
                      disabled={ocrProcessing}
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#18B84E] dark:bg-[#16A249] text-white rounded-lg hover:bg-[#16A249] dark:hover:bg-[#14D45D] disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-150"
                    >
                      {ocrProcessing ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Processing Receipt...
                        </>
                      ) : (
                        <>
                          <Receipt className="w-4 h-4" />
                          Extract Details from Receipt
                        </>
                      )}
                    </button>
                  )}

                  {ocrData && (
                    <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                        <span className="text-sm font-medium text-green-800 dark:text-green-300">
                          Receipt processed successfully!
                        </span>
                      </div>
                      <p className="text-xs text-green-600 dark:text-green-400">
                        Form fields have been auto-filled. Please review and
                        adjust as needed.
                      </p>
                    </div>
                  )}
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>

            {/* Form Fields Section */}
            <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Expense Details
              </h2>

              <div className="space-y-4">
                {/* Title */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    Title *
                  </label>
                  <input
                    {...register("title", { required: "Title is required" })}
                    className="w-full px-4 py-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#18B84E] dark:focus:ring-[#16A249] focus:border-transparent transition-colors duration-150"
                    placeholder="e.g., Client lunch meeting"
                  />
                  {errors.title && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                      {errors.title.message}
                    </p>
                  )}
                </div>

                {/* Amount and Currency */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                      Amount *
                    </label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
                      <input
                        {...register("amount", {
                          required: "Amount is required",
                          pattern: {
                            value: /^\d+(\.\d{1,2})?$/,
                            message: "Enter a valid amount",
                          },
                        })}
                        type="number"
                        step="0.01"
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#18B84E] dark:focus:ring-[#16A249] focus:border-transparent transition-colors duration-150"
                        placeholder="0.00"
                      />
                    </div>
                    {errors.amount && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                        {errors.amount.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                      Currency *
                    </label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
                      <input
                        {...register("currency", {
                          required: "Currency is required",
                        })}
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#18B84E] dark:focus:ring-[#16A249] focus:border-transparent transition-colors duration-150"
                        placeholder="USD"
                      />
                    </div>
                    {errors.currency && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                        {errors.currency.message}
                      </p>
                    )}
                  </div>
                </div>

                {/* Category */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    Category *
                  </label>
                  <select
                    {...register("categoryId", {
                      required: "Category is required",
                    })}
                    className="w-full px-4 py-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#18B84E] dark:focus:ring-[#16A249] focus:border-transparent transition-colors duration-150"
                  >
                    <option value="">Select category</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                  {errors.categoryId && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                      {errors.categoryId.message}
                    </p>
                  )}
                </div>

                {/* Date */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    Expense Date *
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
                    <input
                      {...register("expenseDate", {
                        required: "Date is required",
                      })}
                      type="date"
                      className="w-full pl-10 pr-4 py-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#18B84E] dark:focus:ring-[#16A249] focus:border-transparent transition-colors duration-150"
                    />
                  </div>
                  {errors.expenseDate && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                      {errors.expenseDate.message}
                    </p>
                  )}
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    Description
                  </label>
                  <textarea
                    {...register("description")}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#18B84E] dark:focus:ring-[#16A249] focus:border-transparent transition-colors duration-150"
                    placeholder="Additional details about this expense..."
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                <p className="text-sm text-red-600 dark:text-red-400">
                  {error}
                </p>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={submitting || uploading}
              className="flex items-center gap-2 px-6 py-3 bg-[#18B84E] dark:bg-[#16A249] text-white font-semibold rounded-lg hover:bg-[#16A249] dark:hover:bg-[#14D45D] disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-150"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4" />
                  Submit Expense
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}