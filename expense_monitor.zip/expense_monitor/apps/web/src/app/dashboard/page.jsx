"use client";
import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { 
  Menu, X, Plus, TrendingUp, Clock, CheckCircle, XCircle,
  Receipt, Users, Settings, BarChart3, Calendar,
  DollarSign, ArrowUpRight, ArrowDownRight, Upload,
  Search, Filter, Download
} from "lucide-react";

// Dashboard Layout Component
function DashboardLayout({ children, sidebarOpen, setSidebarOpen, userRole, userName }) {
  const sidebarItems = [
    { icon: BarChart3, label: "Dashboard", path: "/dashboard", active: true },
    { icon: Receipt, label: "Expenses", path: "/expenses" },
    ...(userRole === 'admin' || userRole === 'manager' ? [
      { icon: Clock, label: "Approvals", path: "/approvals" },
    ] : []),
    ...(userRole === 'admin' ? [
      { icon: Users, label: "Team", path: "/team" },
      { icon: Settings, label: "Settings", path: "/settings" }
    ] : [])
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 dark:bg-opacity-70 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-[#1E1E1E] border-r border-gray-200 dark:border-gray-800 transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
        lg:translate-x-0 lg:relative lg:flex-shrink-0
      `}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-[#18B84E] dark:bg-[#16A249] rounded flex items-center justify-center">
              <span className="text-white font-bold text-sm">EX</span>
            </div>
            <div className="ml-2">
              <span className="text-[#111111] dark:text-white font-medium text-lg">
                ExpenseFlow
              </span>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="px-4 space-y-1">
            {sidebarItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <a
                  key={index}
                  href={item.path}
                  className={`
                    group flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-colors duration-150
                    ${item.active
                      ? "bg-white dark:bg-[#262626] text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 shadow-sm dark:shadow-none"
                      : "text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200"
                    }
                  `}
                >
                  <Icon className={`
                    flex-shrink-0 -ml-1 mr-3 h-5 w-5 transition-colors duration-150
                    ${item.active ? "text-gray-900 dark:text-white" : "text-gray-400 dark:text-gray-500 group-hover:text-[#18B84E] dark:group-hover:text-[#16A249]"}
                  `} />
                  <span className="flex-1">{item.label}</span>
                </a>
              );
            })}
          </nav>
        </div>

        {/* User Profile */}
        <div className="border-t border-gray-200 dark:border-gray-800 p-4">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
              <span className="text-gray-600 dark:text-gray-300 font-semibold">
                {userName?.charAt(0)?.toUpperCase() || 'U'}
              </span>
            </div>
            <div className="ml-3 flex-1">
              <p className="text-sm font-semibold text-gray-900 dark:text-white">
                {userName || 'User'}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                {userRole || 'Employee'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile header */}
        <div className="lg:hidden">
          <div className="flex items-center justify-between p-4 bg-white dark:bg-[#1E1E1E] border-b border-gray-200 dark:border-gray-800">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="flex items-center">
              <div className="w-8 h-8 bg-[#18B84E] dark:bg-[#16A249] rounded flex items-center justify-center">
                <span className="text-white font-bold text-sm">EX</span>
              </div>
              <span className="ml-2 text-[#111111] dark:text-white font-medium text-lg">
                ExpenseFlow
              </span>
            </div>
            <div className="w-10" />
          </div>
        </div>

        {/* Page content */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </div>
      </div>
    </div>
  );
}

// Stats Card Component
function StatsCard({ title, value, change, changeType, icon: Icon, trend }) {
  return (
    <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
          {change && (
            <div className="flex items-center mt-2">
              {changeType === 'increase' ? (
                <ArrowUpRight className="w-4 h-4 text-green-500 dark:text-green-400 mr-1" />
              ) : (
                <ArrowDownRight className="w-4 h-4 text-red-500 dark:text-red-400 mr-1" />
              )}
              <span className={`text-sm font-medium ${
                changeType === 'increase' 
                  ? 'text-green-600 dark:text-green-400' 
                  : 'text-red-600 dark:text-red-400'
              }`}>
                {change}
              </span>
              <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">vs last month</span>
            </div>
          )}
        </div>
        <div className="w-12 h-12 bg-gray-50 dark:bg-gray-800 rounded-lg flex items-center justify-center">
          <Icon className="w-6 h-6 text-gray-600 dark:text-gray-400" />
        </div>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { data: user, loading } = useUser();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [companyData, setCompanyData] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [stats, setStats] = useState({
    totalExpenses: 0,
    pendingCount: 0,
    approvedCount: 0,
    rejectedCount: 0
  });
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      window.location.href = "/account/signin?callbackUrl=/dashboard";
    } else if (user) {
      fetchDashboardData();
    }
  }, [user, loading]);

  const fetchDashboardData = async () => {
    try {
      // Fetch company data
      const companyResponse = await fetch("/api/companies");
      if (companyResponse.ok) {
        const company = await companyResponse.json();
        setCompanyData(company);
      } else if (companyResponse.status === 404) {
        // No company found, redirect to setup
        window.location.href = "/setup";
        return;
      }

      // Fetch recent expenses
      const expensesResponse = await fetch("/api/expenses?limit=5");
      if (expensesResponse.ok) {
        const expensesData = await expensesResponse.json();
        setExpenses(expensesData);

        // Calculate stats
        const total = expensesData.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
        const pending = expensesData.filter(exp => exp.expense_status === 'pending').length;
        const approved = expensesData.filter(exp => exp.expense_status === 'approved').length;
        const rejected = expensesData.filter(exp => exp.expense_status === 'rejected').length;

        setStats({
          totalExpenses: total,
          pendingCount: pending,
          approvedCount: approved,
          rejectedCount: rejected
        });
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#18B84E] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <DashboardLayout 
      sidebarOpen={sidebarOpen} 
      setSidebarOpen={setSidebarOpen}
      userRole={companyData?.employee_role}
      userName={user?.name}
    >
      {/* Dashboard Header */}
      <div className="mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white">
          Dashboard
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Welcome back, {user?.name}! Here's your expense overview.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatsCard
          title="Total Expenses"
          value={`${companyData?.base_currency || 'USD'} ${stats.totalExpenses.toFixed(2)}`}
          change="+12.5%"
          changeType="increase"
          icon={DollarSign}
        />
        <StatsCard
          title="Pending Approval"
          value={stats.pendingCount}
          icon={Clock}
        />
        <StatsCard
          title="Approved"
          value={stats.approvedCount}
          change="+8.2%"
          changeType="increase"
          icon={CheckCircle}
        />
        <StatsCard
          title="Rejected"
          value={stats.rejectedCount}
          icon={XCircle}
        />
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <a
            href="/expenses/new"
            className="flex items-center justify-center gap-3 p-4 bg-[#18B84E] dark:bg-[#16A249] text-white rounded-lg hover:bg-[#16A249] dark:hover:bg-[#14D45D] transition-colors duration-150"
          >
            <Plus className="w-5 h-5" />
            <span className="font-medium">Submit Expense</span>
          </a>
          <a
            href="/expenses"
            className="flex items-center justify-center gap-3 p-4 bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-150"
          >
            <Receipt className="w-5 h-5" />
            <span className="font-medium">View All Expenses</span>
          </a>
          {(companyData?.employee_role === 'manager' || companyData?.employee_role === 'admin') && (
            <a
              href="/approvals"
              className="flex items-center justify-center gap-3 p-4 bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-150"
            >
              <Clock className="w-5 h-5" />
              <span className="font-medium">Review Approvals</span>
            </a>
          )}
        </div>
      </div>

      {/* Recent Expenses */}
      <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              Recent Expenses
            </h2>
            <a
              href="/expenses"
              className="text-[#18B84E] dark:text-[#16A249] hover:text-[#16A249] dark:hover:text-[#14D45D] font-medium text-sm"
            >
              View all
            </a>
          </div>
        </div>
        <div className="p-6">
          {expenses.length === 0 ? (
            <div className="text-center py-8">
              <Receipt className="w-12 h-12 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                No expenses yet
              </h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                Start by submitting your first expense
              </p>
              <a
                href="/expenses/new"
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#18B84E] dark:bg-[#16A249] text-white rounded-lg hover:bg-[#16A249] dark:hover:bg-[#14D45D] transition-colors duration-150"
              >
                <Plus className="w-4 h-4" />
                Submit Expense
              </a>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left">
                    <th className="text-sm font-semibold text-gray-600 dark:text-gray-300 pb-3">Title</th>
                    <th className="text-sm font-semibold text-gray-600 dark:text-gray-300 pb-3">Amount</th>
                    <th className="text-sm font-semibold text-gray-600 dark:text-gray-300 pb-3">Date</th>
                    <th className="text-sm font-semibold text-gray-600 dark:text-gray-300 pb-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  {expenses.map((expense) => (
                    <tr key={expense.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                      <td className="py-3 text-gray-900 dark:text-white font-medium">
                        {expense.title}
                      </td>
                      <td className="py-3 text-gray-600 dark:text-gray-300">
                        {expense.currency} {expense.amount}
                      </td>
                      <td className="py-3 text-gray-600 dark:text-gray-300">
                        {new Date(expense.expense_date).toLocaleDateString()}
                      </td>
                      <td className="py-3">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          expense.expense_status === 'approved' 
                            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300'
                            : expense.expense_status === 'rejected'
                            ? 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300'
                            : 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300'
                        }`}>
                          {expense.expense_status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}