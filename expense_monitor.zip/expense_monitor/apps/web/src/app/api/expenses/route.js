import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { title, amount, currency, description, categoryId, expenseDate, receiptUrl, receiptFilename } = await request.json();
    
    if (!title || !amount || !currency || !categoryId || !expenseDate) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Get current employee info
    const employee = await sql`
      SELECT e.*, c.base_currency 
      FROM employees e 
      JOIN companies c ON e.company_id = c.id 
      WHERE e.user_id = ${session.user.id} AND e.employee_status = 'active'
    `;

    if (employee.length === 0) {
      return Response.json({ error: 'Employee not found' }, { status: 404 });
    }

    const { id: employeeId, base_currency } = employee[0];

    // Convert currency if needed
    let amountBaseCurrency = amount;
    if (currency !== base_currency) {
      try {
        const conversionResponse = await fetch(`${process.env.BASE_URL || 'http://localhost:3000'}/api/currency/convert`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ amount, fromCurrency: currency, toCurrency: base_currency })
        });
        const conversion = await conversionResponse.json();
        if (conversion.convertedAmount) {
          amountBaseCurrency = conversion.convertedAmount;
        }
      } catch (error) {
        console.error('Currency conversion failed:', error);
      }
    }

    const [expense] = await sql`
      INSERT INTO expenses (
        employee_id, category_id, amount, currency, amount_base_currency,
        title, description, expense_date, receipt_url, receipt_filename
      ) VALUES (
        ${employeeId}, ${categoryId}, ${amount}, ${currency}, ${amountBaseCurrency},
        ${title}, ${description}, ${expenseDate}, ${receiptUrl || null}, ${receiptFilename || null}
      ) RETURNING *
    `;

    return Response.json(expense);
  } catch (error) {
    console.error('Error creating expense:', error);
    return Response.json({ error: 'Failed to create expense' }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const status = url.searchParams.get('status');
    const limit = parseInt(url.searchParams.get('limit')) || 50;

    // Get current employee info
    const employee = await sql`
      SELECT e.*, c.id as company_id, c.base_currency 
      FROM employees e 
      JOIN companies c ON e.company_id = c.id 
      WHERE e.user_id = ${session.user.id} AND e.employee_status = 'active'
    `;

    if (employee.length === 0) {
      return Response.json({ error: 'Employee not found' }, { status: 404 });
    }

    const { id: employeeId, employee_role, company_id } = employee[0];

    let whereClause = '';
    let params = [];

    // Role-based filtering
    if (employee_role === 'admin') {
      // Admin sees all expenses in company
      whereClause = 'WHERE emp.company_id = $1';
      params = [company_id];
    } else if (employee_role === 'manager') {
      // Manager sees team expenses and own expenses
      whereClause = 'WHERE (emp.manager_id = $1 OR exp.employee_id = $1)';
      params = [employeeId];
    } else {
      // Employee sees only own expenses
      whereClause = 'WHERE exp.employee_id = $1';
      params = [employeeId];
    }

    // Add status filter if provided
    if (status) {
      whereClause += ` AND exp.expense_status = $${params.length + 1}`;
      params.push(status);
    }

    const query = `
      SELECT 
        exp.*,
        cat.name as category_name,
        u.name as employee_name,
        u.email as employee_email
      FROM expenses exp
      JOIN employees emp ON exp.employee_id = emp.id
      JOIN auth_users u ON emp.user_id = u.id
      LEFT JOIN expense_categories cat ON exp.category_id = cat.id
      ${whereClause}
      ORDER BY exp.created_at DESC
      LIMIT $${params.length + 1}
    `;

    params.push(limit);

    const expenses = await sql(query, params);

    return Response.json(expenses);
  } catch (error) {
    console.error('Error fetching expenses:', error);
    return Response.json({ error: 'Failed to fetch expenses' }, { status: 500 });
  }
}