import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get current employee's company
    const employee = await sql`
      SELECT company_id FROM employees 
      WHERE user_id = ${session.user.id} AND employee_status = 'active'
    `;

    if (employee.length === 0) {
      return Response.json({ error: 'Employee not found' }, { status: 404 });
    }

    const companyId = employee[0].company_id;

    const categories = await sql`
      SELECT * FROM expense_categories 
      WHERE company_id = ${companyId} AND is_active = true 
      ORDER BY name
    `;

    return Response.json(categories);
  } catch (error) {
    console.error('Error fetching expense categories:', error);
    return Response.json({ error: 'Failed to fetch expense categories' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { name, description } = await request.json();
    
    if (!name) {
      return Response.json({ error: 'Category name is required' }, { status: 400 });
    }

    // Check if current user is admin
    const employee = await sql`
      SELECT company_id FROM employees 
      WHERE user_id = ${session.user.id} AND employee_role = 'admin' AND employee_status = 'active'
    `;

    if (employee.length === 0) {
      return Response.json({ error: 'Only admins can create expense categories' }, { status: 403 });
    }

    const companyId = employee[0].company_id;

    const [category] = await sql`
      INSERT INTO expense_categories (company_id, name, description) 
      VALUES (${companyId}, ${name}, ${description || null}) 
      RETURNING *
    `;

    return Response.json(category);
  } catch (error) {
    console.error('Error creating expense category:', error);
    return Response.json({ error: 'Failed to create expense category' }, { status: 500 });
  }
}