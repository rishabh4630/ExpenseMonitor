import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { name, countryCode, baseCurrency } = await request.json();
    
    if (!name || !countryCode || !baseCurrency) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Use transaction to create company and admin employee record
    const [companyResult, employeeResult] = await sql.transaction([
      sql`INSERT INTO companies (name, country_code, base_currency) 
          VALUES (${name}, ${countryCode}, ${baseCurrency}) 
          RETURNING *`,
      sql`INSERT INTO employees (user_id, company_id, employee_role, employee_status) 
          VALUES (${session.user.id}, (SELECT id FROM companies WHERE name = ${name} ORDER BY id DESC LIMIT 1), 'admin', 'active') 
          RETURNING *`
    ]);

    const company = companyResult[0];
    const employee = employeeResult[0];

    return Response.json({ company, employee });
  } catch (error) {
    console.error('Error creating company:', error);
    return Response.json({ error: 'Failed to create company' }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get company info for current user
    const result = await sql`
      SELECT c.*, e.employee_role, e.department, e.job_title
      FROM companies c
      JOIN employees e ON c.id = e.company_id
      WHERE e.user_id = ${session.user.id} AND e.employee_status = 'active'
    `;

    if (result.length === 0) {
      return Response.json({ error: 'No company found for user' }, { status: 404 });
    }

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error fetching company:', error);
    return Response.json({ error: 'Failed to fetch company' }, { status: 500 });
  }
}