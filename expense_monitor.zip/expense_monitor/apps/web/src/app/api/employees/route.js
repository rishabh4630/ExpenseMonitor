import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { email, name, role, department, jobTitle, managerId } = await request.json();
    
    if (!email || !name || !role) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Check if current user is admin
    const currentEmployee = await sql`
      SELECT e.*, c.id as company_id 
      FROM employees e 
      JOIN companies c ON e.company_id = c.id 
      WHERE e.user_id = ${session.user.id} AND e.employee_role = 'admin'
    `;

    if (currentEmployee.length === 0) {
      return Response.json({ error: 'Only admins can create employees' }, { status: 403 });
    }

    const companyId = currentEmployee[0].company_id;

    // Create user account first, then employee record
    const [userResult] = await sql`
      INSERT INTO auth_users (email, name) 
      VALUES (${email}, ${name}) 
      RETURNING *
    `;

    const [employeeResult] = await sql`
      INSERT INTO employees (user_id, company_id, employee_role, department, job_title, manager_id) 
      VALUES (${userResult.id}, ${companyId}, ${role}, ${department}, ${jobTitle}, ${managerId || null}) 
      RETURNING *
    `;

    return Response.json({ user: userResult, employee: employeeResult });
  } catch (error) {
    console.error('Error creating employee:', error);
    return Response.json({ error: 'Failed to create employee' }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get current user's company
    const currentEmployee = await sql`
      SELECT company_id, employee_role FROM employees 
      WHERE user_id = ${session.user.id} AND employee_status = 'active'
    `;

    if (currentEmployee.length === 0) {
      return Response.json({ error: 'Employee not found' }, { status: 404 });
    }

    const { company_id, employee_role } = currentEmployee[0];

    // Get all employees in the same company
    const employees = await sql`
      SELECT 
        e.*,
        u.name,
        u.email,
        m.name as manager_name
      FROM employees e
      JOIN auth_users u ON e.user_id = u.id
      LEFT JOIN employees mg ON e.manager_id = mg.id
      LEFT JOIN auth_users m ON mg.user_id = m.id
      WHERE e.company_id = ${company_id}
      ORDER BY e.employee_role, u.name
    `;

    return Response.json(employees);
  } catch (error) {
    console.error('Error fetching employees:', error);
    return Response.json({ error: 'Failed to fetch employees' }, { status: 500 });
  }
}