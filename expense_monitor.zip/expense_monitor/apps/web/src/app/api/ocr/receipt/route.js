export async function POST(request) {
  try {
    const { imageBase64 } = await request.json();
    
    if (!imageBase64) {
      return Response.json({ error: 'Image is required' }, { status: 400 });
    }

    // Use GPT Vision to extract receipt information
    const response = await fetch('/integrations/gpt-vision/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messages: [{
          "role": "user",
          "content": [
            {
              "type": "text",
              "text": "Please extract the following information from this receipt image and return it as a JSON object: {\"amount\": number, \"currency\": \"3-letter currency code\", \"merchant\": \"merchant name\", \"date\": \"YYYY-MM-DD\", \"description\": \"brief description of the purchase\", \"category\": \"expense category like Travel, Meals, Office Supplies, etc.\"}. If any information is not clear or available, use null for that field."
            },
            {
              "type": "image_url",
              "image_url": {
                "url": imageBase64
              }
            }
          ]
        }]
      })
    });

    if (!response.ok) {
      throw new Error('OCR processing failed');
    }

    const ocrResult = await response.json();
    const content = ocrResult.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('No content returned from OCR');
    }

    // Try to parse JSON from the response
    let extractedData = {};
    try {
      // Look for JSON in the response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        extractedData = JSON.parse(jsonMatch[0]);
      } else {
        // If no JSON found, return empty object
        extractedData = {
          amount: null,
          currency: null,
          merchant: null,
          date: null,
          description: null,
          category: null
        };
      }
    } catch (parseError) {
      console.error('Failed to parse OCR JSON:', parseError);
      extractedData = {
        amount: null,
        currency: null,
        merchant: null,
        date: null,
        description: null,
        category: null,
        rawResponse: content
      };
    }

    return Response.json({
      success: true,
      extractedData,
      rawResponse: content
    });

  } catch (error) {
    console.error('OCR error:', error);
    return Response.json({ 
      error: 'Failed to process receipt', 
      details: error.message 
    }, { status: 500 });
  }
}