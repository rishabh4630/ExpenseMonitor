export async function GET(request) {
  try {
    const response = await fetch('https://restcountries.com/v3.1/all?fields=name,currencies,cca2');
    
    if (!response.ok) {
      throw new Error('Failed to fetch countries');
    }
    
    const countries = await response.json();
    
    // Format countries with currency info
    const formattedCountries = countries.map(country => {
      const currencies = country.currencies ? Object.keys(country.currencies) : [];
      const firstCurrency = currencies[0];
      const currencyName = firstCurrency && country.currencies[firstCurrency] 
        ? country.currencies[firstCurrency].name 
        : '';
      
      return {
        code: country.cca2,
        name: country.name.common,
        currency: firstCurrency || 'USD',
        currencyName: currencyName
      };
    }).sort((a, b) => a.name.localeCompare(b.name));

    return Response.json(formattedCountries);
  } catch (error) {
    console.error('Error fetching countries:', error);
    return Response.json({ error: 'Failed to fetch countries' }, { status: 500 });
  }
}