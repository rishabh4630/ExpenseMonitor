export async function POST(request) {
  try {
    const { amount, fromCurrency, toCurrency } = await request.json();
    
    if (!amount || !fromCurrency || !toCurrency) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    if (fromCurrency === toCurrency) {
      return Response.json({ convertedAmount: amount, rate: 1 });
    }

    const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${fromCurrency}`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch exchange rates');
    }
    
    const data = await response.json();
    const rate = data.rates[toCurrency];
    
    if (!rate) {
      return Response.json({ error: 'Currency conversion not available' }, { status: 400 });
    }
    
    const convertedAmount = parseFloat((amount * rate).toFixed(2));
    
    return Response.json({ 
      convertedAmount, 
      rate,
      fromCurrency,
      toCurrency,
      originalAmount: amount
    });
  } catch (error) {
    console.error('Error converting currency:', error);
    return Response.json({ error: 'Failed to convert currency' }, { status: 500 });
  }
}