const axios = require('axios');

exports.countriesCurrencies = async (_req, res) => {
  const response = await axios.get('https://restcountries.com/v3.1/all?fields=name,currencies');
  res.json(response.data);
};

exports.currencyRate = async (req, res) => {
  const { base, target } = req.params;
  const response = await axios.get(`https://api.exchangerate-api.com/v4/latest/${base}`);
  res.json({ rate: response.data.rates[target] });
};