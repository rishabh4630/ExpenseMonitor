// For server-side OCR, you'd use Google Vision, AWS Textract, etc.
// Here is a placeholder for integration.
exports.scanReceipt = async (req, res) => {
  // req.file contains the image
  res.json({ amount: '', date: '', merchant: '', description: '' });
};