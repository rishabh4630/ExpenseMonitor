const Expense = require('../models/expense');
const ExpenseApproval = require('../models/expenseApproval');
const ApprovalRule = require('../models/approvalRule');

exports.submitExpense = async (req, res) => {
  const { employee_id, amount, currency, category, description, date, company_id } = req.body;
  const receipt_url = req.file ? req.file.path : '';
  try {
    const expense = await Expense.create({
      employee_id, company_id, amount, currency, category, description, date, status: 'pending', receipt_url
    });
    res.json(expense);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.listExpenses = async (req, res) => {
  const { employee_id } = req.query;
  const expenses = await Expense.findAll({ where: { employee_id } });
  res.json(expenses);
};