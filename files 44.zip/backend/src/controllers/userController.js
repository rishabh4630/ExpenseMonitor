const bcrypt = require('bcryptjs');
const User = require('../models/user');

exports.createUser = async (req, res) => {
  const { name, email, password, role, manager_id, company_id } = req.body;
  try {
    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({
      name, email, password: hashed, role, manager_id, company_id
    });
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.listUsers = async (req, res) => {
  const users = await User.findAll();
  res.json(users);
};