const ExpenseApproval = require('../models/expenseApproval');
const Expense = require('../models/expense');
const ApprovalRule = require('../models/approvalRule');

const getRule = async (company_id) => {
  return await ApprovalRule.findOne({ where: { company_id } });
};

exports.pendingApprovals = async (req, res) => {
  const { approver_id } = req.query;
  const approvals = await ExpenseApproval.findAll({ where: { approver_id, status: 'pending' } });
  res.json(approvals);
};

exports.approveOrReject = async (req, res) => {
  const { expense_id } = req.params;
  const { approver_id, action, comments } = req.body;
  try {
    const approval = await ExpenseApproval.findOne({ where: { expense_id, approver_id, status: 'pending' } });
    if (!approval) throw new Error('No pending approval');
    approval.status = action;
    approval.comments = comments;
    approval.approved_at = new Date();
    await approval.save();

    const expense = await Expense.findByPk(expense_id);
    const rule = await getRule(expense.company_id);
    const allApprovals = await ExpenseApproval.findAll({ where: { expense_id } });

    let approvedCount = allApprovals.filter(a => a.status === 'approved').length;
    let total = rule.approver_sequence.length;

    if (rule.rule_type === 'sequential') {
      if (approval.sequence_num === total && action === 'approved') {
        expense.status = 'approved';
        await expense.save();
      }
    } else if (rule.rule_type === 'conditional') {
      if ((approvedCount / total) >= rule.percentage_required) {
        expense.status = 'approved';
        await expense.save();
      }
      if (rule.specific_approver_id && approver_id === rule.specific_approver_id && action === 'approved') {
        expense.status = 'approved';
        await expense.save();
      }
    } else if (rule.rule_type === 'hybrid') {
      if ((approvedCount / total) >= rule.percentage_required || 
          (rule.specific_approver_id && approver_id === rule.specific_approver_id && action === 'approved')) {
        expense.status = 'approved';
        await expense.save();
      }
    }

    if (action === 'rejected') {
      expense.status = 'rejected';
      await expense.save();
    }

    res.json({ approval, expense });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};