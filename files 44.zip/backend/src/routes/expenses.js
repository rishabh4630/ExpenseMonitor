const express = require('express');
const router = express.Router();
const expenseController = require('../controllers/expenseController');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

router.post('/', upload.single('receipt'), expenseController.submitExpense);
router.get('/', expenseController.listExpenses);

module.exports = router;