const express = require('express');
const router = express.Router();
const metaController = require('../controllers/metaController');

router.get('/countries-currencies', metaController.countriesCurrencies);
router.get('/currency-rate/:base/:target', metaController.currencyRate);

module.exports = router;