const express = require('express');
const router = express.Router();
const approvalController = require('../controllers/approvalController');

router.get('/pending', approvalController.pendingApprovals);
router.post('/:expense_id/action', approvalController.approveOrReject);

module.exports = router;