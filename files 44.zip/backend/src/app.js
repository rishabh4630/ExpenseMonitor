const express = require('express');
const cors = require('cors');
const app = express();
const bodyParser = require('body-parser');
const sequelize = require('./config/database');
require('dotenv').config();

app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(bodyParser.json());

app.use('/auth', require('./routes/auth'));
app.use('/users', require('./routes/users'));
app.use('/expenses', require('./routes/expenses'));
app.use('/approval', require('./routes/approval'));
app.use('/meta', require('./routes/meta'));

app.get('/', (req, res) => res.send('Expense Management System API'));

const PORT = process.env.PORT || 4000;
sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
});