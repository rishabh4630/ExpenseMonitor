const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ApprovalRule = sequelize.define('ApprovalRule', {
  company_id: DataTypes.INTEGER,
  rule_type: DataTypes.ENUM('sequential', 'conditional', 'hybrid'),
  approver_sequence: DataTypes.JSON,
  percentage_required: DataTypes.FLOAT,
  specific_approver_id: DataTypes.INTEGER,
  hybrid_logic: DataTypes.JSON
});

module.exports = ApprovalRule;