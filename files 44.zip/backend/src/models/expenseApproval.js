const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ExpenseApproval = sequelize.define('ExpenseApproval', {
  expense_id: DataTypes.INTEGER,
  approver_id: DataTypes.INTEGER,
  sequence_num: DataTypes.INTEGER,
  status: DataTypes.ENUM('pending', 'approved', 'rejected'),
  comments: DataTypes.TEXT,
  approved_at: DataTypes.DATE
});

module.exports = ExpenseApproval;