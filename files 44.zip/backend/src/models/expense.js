const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Expense = sequelize.define('Expense', {
  employee_id: DataTypes.INTEGER,
  company_id: DataTypes.INTEGER,
  amount: DataTypes.FLOAT,
  currency: DataTypes.STRING,
  category: DataTypes.STRING,
  description: DataTypes.TEXT,
  date: DataTypes.DATE,
  status: DataTypes.ENUM('pending', 'approved', 'rejected'),
  receipt_url: DataTypes.STRING
});

module.exports = Expense;