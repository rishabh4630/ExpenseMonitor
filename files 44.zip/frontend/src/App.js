import React from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';

function App() {
  // For demo: login then dashboard
  return (
    <div>
      <h1>Expense Management System</h1>
      <Login />
      <Dashboard />
    </div>
  );
}

export default App;