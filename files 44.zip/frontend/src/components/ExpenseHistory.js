import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ExpenseHistory = () => {
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    // You should replace 'employee_id' with the logged-in user's id
    axios.get(`http://localhost:4000/expenses?employee_id=1`).then(res => {
      setExpenses(res.data);
    });
  }, []);

  return (
    <div>
      <h3>My Expense History</h3>
      <ul>
        {expenses.map(exp => (
          <li key={exp.id}>
            {exp.date} | {exp.amount} | {exp.category} | {exp.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExpenseHistory;