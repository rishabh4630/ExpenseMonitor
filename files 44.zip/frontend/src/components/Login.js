import React from 'react';

const Login = () => (
  <div>
    <h2>Login</h2>
    <form>
      <input type="email" placeholder="Email" /><br />
      <input type="password" placeholder="Password" /><br />
      <button type="submit">Login</button>
    </form>
  </div>
);

export default Login;