import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ApprovalDashboard = () => {
  const [pending, setPending] = useState([]);

  useEffect(() => {
    // Replace 'approver_id' with the logged-in user's id
    axios.get(`http://localhost:4000/approval/pending?approver_id=1`).then(res => {
      setPending(res.data);
    });
  }, []);

  const handleAction = (expense_id, action) => {
    axios.post(`http://localhost:4000/approval/${expense_id}/action`, {
      approver_id: 1, // Replace with logged-in user id
      action,
      comments: ''
    }).then(() => {
      setPending(pending.filter(p => p.expense_id !== expense_id));
    });
  };

  return (
    <div>
      <h3>Approval Dashboard</h3>
      <ul>
        {pending.map(p => (
          <li key={p.expense_id}>
            Expense #{p.expense_id} | <button onClick={() => handleAction(p.expense_id, "approved")}>Approve</button>
            <button onClick={() => handleAction(p.expense_id, "rejected")}>Reject</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ApprovalDashboard;