import React, { useState } from 'react';
import ReceiptOCR from './ReceiptOCR';
import axios from 'axios';

const ExpenseForm = () => {
  const [fields, setFields] = useState({
    amount: '',
    date: '',
    merchant: '',
    description: '',
    category: '',
  });
  const [receipt, setReceipt] = useState(null);

  const handleOCRExtract = (ocrFields) => {
    setFields((prev) => ({ ...prev, ...ocrFields }));
  };

  const handleFileChange = e => setReceipt(e.target.files[0]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    Object.keys(fields).forEach(key => formData.append(key, fields[key]));
    formData.append("receipt", receipt);
    await axios.post('http://localhost:4000/expenses', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    // Show success message, reset form, etc.
  };

  return (
    <div>
      <h3>Submit Expense</h3>
      <ReceiptOCR onExtract={handleOCRExtract} />
      <form onSubmit={handleSubmit}>
        <input type="number" placeholder="Amount" value={fields.amount}
          onChange={e => setFields({ ...fields, amount: e.target.value })} /><br />
        <input type="date" value={fields.date}
          onChange={e => setFields({ ...fields, date: e.target.value })} /><br />
        <input type="text" placeholder="Merchant" value={fields.merchant}
          onChange={e => setFields({ ...fields, merchant: e.target.value })} /><br />
        <input type="text" placeholder="Description" value={fields.description}
          onChange={e => setFields({ ...fields, description: e.target.value })} /><br />
        <input type="text" placeholder="Category" value={fields.category}
          onChange={e => setFields({ ...fields, category: e.target.value })} /><br />
        <input type="file" onChange={handleFileChange} /><br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ExpenseForm;