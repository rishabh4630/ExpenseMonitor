import React, { useState } from 'react';
import Tesseract from 'tesseract.js';

const ReceiptOCR = ({ onExtract }) => {
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');

  const handleImageUpload = (e) => {
    setImage(e.target.files[0]);
  };

  const extractFields = (text) => {
    // Example RegEx for extracting fields
    const amountMatch = text.match(/(?:Total|Amount|Sum)[^0-9]*([\d,.]+)/i);
    const dateMatch = text.match(/(\d{2,4}[\/\-\.]\d{1,2}[\/\-\.]\d{1,4})/);
    const merchantMatch = text.match(/(?:at|from|restaurant)\s+([A-Za-z\s]+)/i);
    return {
      amount: amountMatch ? amountMatch[1] : '',
      date: dateMatch ? dateMatch[1] : '',
      merchant: merchantMatch ? merchantMatch[1] : '',
      description: text.slice(0, 100),
    };
  };

  const handleScan = async () => {
    if (!image) return;
    setLoading(true);
    const { data: { text } } = await Tesseract.recognize(image, 'eng');
    setResult(text);
    setLoading(false);
    const fields = extractFields(text);
    onExtract(fields);
  };

  return (
    <div>
      <h3>Scan Receipt (OCR)</h3>
      <input type="file" accept="image/*" onChange={handleImageUpload} /><br />
      <button onClick={handleScan} disabled={!image || loading}>
        {loading ? 'Scanning...' : 'Scan & Autofill'}
      </button>
      {result && <pre>{result}</pre>}
    </div>
  );
};

export default ReceiptOCR;