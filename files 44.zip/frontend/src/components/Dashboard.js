import React from 'react';
import ExpenseForm from './ExpenseForm';
import ExpenseHistory from './ExpenseHistory';
import ApprovalDashboard from './ApprovalDashboard';

const Dashboard = () => (
  <div>
    <h2>Dashboard</h2>
    <ExpenseForm />
    <ExpenseHistory />
    <ApprovalDashboard />
  </div>
);

export default Dashboard;